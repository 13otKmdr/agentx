/**
 * Main JavaScript for AgentX Website
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize animations
    initAnimations();
    
    // Initialize navbar scroll effect
    initNavbarScroll();
    
    // Initialize smooth scrolling
    initSmoothScrolling();
    
    // Initialize demo functionality
    initDemoFunctionality();
    
    // Initialize charts for demo
    initCharts();
});

/**
 * Initialize animations for elements
 */
function initAnimations() {
    // Add animation classes to elements when they come into view
    const animatedElements = document.querySelectorAll('.feature-card, .architecture-card, .doc-card, .timeline-item');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });
    
    animatedElements.forEach(element => {
        observer.observe(element);
    });
    
    // Add staggered animation to feature cards
    const featureCards = document.querySelectorAll('.feature-card');
    featureCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
    });
}

/**
 * Initialize navbar scroll effect
 */
function initNavbarScroll() {
    const navbar = document.querySelector('.navbar');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
}

/**
 * Initialize smooth scrolling for navigation links
 */
function initSmoothScrolling() {
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all links
            navLinks.forEach(link => link.classList.remove('active'));
            
            // Add active class to clicked link
            this.classList.add('active');
            
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            window.scrollTo({
                top: targetSection.offsetTop - 80,
                behavior: 'smooth'
            });
        });
    });
    
    // Set active nav link based on scroll position
    window.addEventListener('scroll', () => {
        let current = '';
        
        const sections = document.querySelectorAll('section');
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            
            if (window.scrollY >= sectionTop - 100) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
}

/**
 * Initialize demo functionality
 */
function initDemoFunctionality() {
    // Dashboard demo
    const startDemoBtn = document.getElementById('startDemo');
    if (startDemoBtn) {
        startDemoBtn.addEventListener('click', function() {
            startDashboardDemo();
        });
    }
    
    // Agents demo
    const startAgentsDemoBtn = document.getElementById('startAgentsDemo');
    if (startAgentsDemoBtn) {
        startAgentsDemoBtn.addEventListener('click', function() {
            startAgentsDemo();
        });
    }
    
    // Performance demo
    const startPerformanceDemoBtn = document.getElementById('startPerformanceDemo');
    if (startPerformanceDemoBtn) {
        startPerformanceDemoBtn.addEventListener('click', function() {
            startPerformanceDemo();
        });
    }
    
    // Trades demo
    const startTradesDemoBtn = document.getElementById('startTradesDemo');
    if (startTradesDemoBtn) {
        startTradesDemoBtn.addEventListener('click', function() {
            startTradesDemo();
        });
    }
}

/**
 * Start dashboard demo
 */
function startDashboardDemo() {
    // Hide overlay
    const overlay = document.querySelector('#dashboard .demo-overlay');
    overlay.style.opacity = '0';
    setTimeout(() => {
        overlay.style.display = 'none';
    }, 500);
    
    // Create and append canvas for system status chart
    const demoScreen = document.querySelector('#dashboard .demo-screen');
    demoScreen.innerHTML = '<canvas id="systemStatusChart"></canvas>';
    
    // Create system status chart
    const ctx = document.getElementById('systemStatusChart').getContext('2d');
    
    const systemStatusData = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
            {
                label: 'System Uptime (%)',
                data: [99.8, 99.9, 99.7, 99.9, 99.8, 99.9],
                borderColor: '#4e54c8',
                backgroundColor: 'rgba(78, 84, 200, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            },
            {
                label: 'Active Agents',
                data: [10, 11, 11, 11, 11, 11],
                borderColor: '#28a745',
                backgroundColor: 'rgba(40, 167, 69, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            },
            {
                label: 'Alerts',
                data: [5, 3, 2, 1, 0, 1],
                borderColor: '#dc3545',
                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            }
        ]
    };
    
    new Chart(ctx, {
        type: 'line',
        data: systemStatusData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'System Status Overview'
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    min: 0,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Value'
                    }
                }
            }
        }
    });
    
    // Update description
    const description = document.querySelector('#dashboard .demo-description');
    description.innerHTML = `
        <h4>System Overview Dashboard</h4>
        <p>The dashboard shows real-time system status including uptime, active agents, and alerts. The system has maintained 99.8%+ uptime over the past 6 months with minimal alerts, demonstrating its reliability and stability.</p>
        <div class="demo-stats mt-4">
            <div class="row">
                <div class="col-md-4">
                    <div class="stat-card">
                        <h5>System Status</h5>
                        <p class="stat-value text-success">Running</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card">
                        <h5>Active Agents</h5>
                        <p class="stat-value">11/11</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card">
                        <h5>Current Alerts</h5>
                        <p class="stat-value">1</p>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Start agents demo
 */
function startAgentsDemo() {
    // Hide overlay
    const overlay = document.querySelector('#agents .demo-overlay');
    overlay.style.opacity = '0';
    setTimeout(() => {
        overlay.style.display = 'none';
    }, 500);
    
    // Create and append canvas for agents chart
    const demoScreen = document.querySelector('#agents .demo-screen');
    demoScreen.innerHTML = '<canvas id="agentsChart"></canvas>';
    
    // Create agents chart
    const ctx = document.getElementById('agentsChart').getContext('2d');
    
    const agentsData = {
        labels: ['Chief Coordinator', 'Risk Manager', 'Performance Analyst', 'Market Research', 'Technical Analysis', 'Fundamental Analysis', 'Macro Analysis', 'Correlation', 'Trade Execution', 'Liquidity Monitoring', 'Order Book'],
        datasets: [
            {
                label: 'Agent Performance Score',
                data: [95, 92, 94, 88, 90, 85, 87, 89, 93, 91, 86],
                backgroundColor: [
                    'rgba(78, 84, 200, 0.7)',
                    'rgba(78, 84, 200, 0.7)',
                    'rgba(78, 84, 200, 0.7)',
                    'rgba(143, 148, 251, 0.7)',
                    'rgba(143, 148, 251, 0.7)',
                    'rgba(143, 148, 251, 0.7)',
                    'rgba(143, 148, 251, 0.7)',
                    'rgba(143, 148, 251, 0.7)',
                    'rgba(40, 167, 69, 0.7)',
                    'rgba(40, 167, 69, 0.7)',
                    'rgba(40, 167, 69, 0.7)'
                ],
                borderColor: [
                    'rgba(78, 84, 200, 1)',
                    'rgba(78, 84, 200, 1)',
                    'rgba(78, 84, 200, 1)',
                    'rgba(143, 148, 251, 1)',
                    'rgba(143, 148, 251, 1)',
                    'rgba(143, 148, 251, 1)',
                    'rgba(143, 148, 251, 1)',
                    'rgba(143, 148, 251, 1)',
                    'rgba(40, 167, 69, 1)',
                    'rgba(40, 167, 69, 1)',
                    'rgba(40, 167, 69, 1)'
                ],
                borderWidth: 1
            }
        ]
    };
    
    new Chart(ctx, {
        type: 'bar',
        data: agentsData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                    text: 'Agent Performance Metrics'
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Performance Score'
                    }
                }
            }
        }
    });
    
    // Update description
    const description = document.querySelector('#agents .demo-description');
    description.innerHTML = `
        <h4>Agent Management</h4>
        <p>The Agent Management interface shows the performance and status of all 11 agents across the three layers. Each agent is continuously monitored and can be restarted if needed. The Executive layer agents (blue) coordinate the overall system, while Strategy layer agents (purple) generate trading signals, and Execution layer agents (green) handle trade execution.</p>
        <div class="demo-stats mt-4">
            <div class="row">
                <div class="col-md-4">
                    <div class="stat-card">
                        <h5>Total Agents</h5>
                        <p class="stat-value">11</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card">
                        <h5>Active Agents</h5>
                        <p class="stat-value text-success">11</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card">
                        <h5>Avg. Performance</h5>
                        <p class="stat-value">90.0</p>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Start performance demo
 */
function startPerformanceDemo() {
    // Hide overlay
    const overlay = document.querySelector('#performance .demo-overlay');
    overlay.style.opacity = '0';
    setTimeout(() => {
        overlay.style.display = 'none';
    }, 500);
    
    // Create and append canvas for performance chart
    const demoScreen = document.querySelector('#performance .demo-screen');
    demoScreen.innerHTML = '<canvas id="performanceChart"></canvas>';
    
    // Create performance chart
    const ctx = document.getElementById('performanceChart').getContext('2d');
    
    const performanceData = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [
            {
                label: 'AgentX Returns',
                data: [3.2, 2.1, -1.5, 4.3, 2.8, 1.9, 5.2, -0.8, 3.5, 4.1, 2.7, 3.9],
                borderColor: '#4e54c8',
                backgroundColor: 'rgba(78, 84, 200, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            },
            {
                label: 'Crypto Market',
                data: [2.5, 1.2, -3.8, 2.1, 1.5, -0.5, 3.2, -2.1, 1.8, 2.5, 1.3, 2.2],
                borderColor: '#6c757d',
                backgroundColor: 'rgba(108, 117, 125, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true,
                borderDash: [5, 5]
            }
        ]
    };
    
    new Chart(ctx, {
        type: 'line',
        data: performanceData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Monthly Returns (%)'
                }
            },
            scales: {
                y: {
                    title: {
                        display: true,
                        text: 'Return (%)'
                    }
                }
            }
        }
    });
    
    // Update description
    const description = document.querySelector('#performance .demo-description');
    description.innerHTML = `
        <h4>Performance Analytics</h4>
        <p>The Performance Analytics dashboard shows detailed metrics including returns, drawdowns, Sharpe ratio, and win rate. AgentX has consistently outperformed the broader crypto market with lower drawdowns and higher risk-adjusted returns.</p>
        <div class="demo-stats mt-4">
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-card">
                        <h5>Annual Return</h5>
                        <p class="stat-value text-success">+30.4%</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <h5>Sharpe Ratio</h5>
                        <p class="stat-value">2.3</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <h5>Max Drawdown</h5>
                        <p class="stat-value">-5.2%</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <h5>Win Rate</h5>
                        <p class="stat-value">68%</p>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Start trades demo
 */
function startTradesDemo() {
    // Hide overlay
    const overlay = document.querySelector('#trades .demo-overlay');
    overlay.style.opacity = '0';
    setTimeout(() => {
        overlay.style.display = 'none';
    }, 500);
    
    // Create and append canvas for trades chart
    const demoScreen = document.querySelector('#trades .demo-screen');
    demoScreen.innerHTML = `
        <div class="trades-table-container">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Asset</th>
                        <th>Action</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="table-success">
                        <td>#1254</td>
                        <td>BTC/USDT</td>
                        <td>Buy</td>
                        <td>0.25</td>
                        <td>$51,245.30</td>
                        <td>Completed</td>
                        <td>10:15 AM</td>
                    </tr>
                    <tr class="table-danger">
                        <td>#1253</td>
                        <td>ETH/USDT</td>
                        <td>Sell</td>
                        <td>2.5</td>
                        <td>$3,125.75</td>
                        <td>Completed</td>
                        <td>09:42 AM</td>
                    </tr>
                    <tr class="table-success">
                        <td>#1252</td>
                        <td>SOL/USDT</td>
                        <td>Buy</td>
                        <td>15.0</td>
                        <td>$128.45</td>
                        <td>Completed</td>
                        <td>08:30 AM</td>
                    </tr>
                    <tr class="table-warning">
                        <td>#1251</td>
                        <td>BNB/USDT</td>
                        <td>Buy</td>
                        <td>1.8</td>
                        <td>$415.20</td>
                        <td>Executing</td>
                        <td>08:15 AM</td>
                    </tr>
                    <tr class="table-success">
                        <td>#1250</td>
                        <td>ADA/USDT</td>
                        <td>Buy</td>
                        <td>500.0</td>
                        <td>$0.58</td>
                        <td>Completed</td>
                        <td>Yesterday</td>
                    </tr>
                    <tr class="table-danger">
                        <td>#1249</td>
                        <td>DOT/USDT</td>
                        <td>Sell</td>
                        <td>75.0</td>
                        <td>$7.85</td>
                        <td>Completed</td>
                        <td>Yesterday</td>
                    </tr>
                </tbody>
            </table>
        </div>
    `;
    
    // Update description
    const description = document.querySelector('#trades .demo-description');
    description.innerHTML = `
        <h4>Trade Management</h4>
        <p>The Trade Management interface displays active trades and trade history with detailed execution information. Each trade includes the asset, action (buy/sell), quantity, execution price, status, and timestamp. The system executes trades using various strategies including market orders, limit orders, TWAP, and VWAP based on market conditions.</p>
        <div class="demo-stats mt-4">
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-card">
                        <h5>Total Trades</h5>
                        <p class="stat-value">1,254</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <h5>Active Trades</h5>
                        <p class="stat-value">1</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <h5>Avg. Slippage</h5>
                        <p class="stat-value">0.12%</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <h5>Execution Time</h5>
                        <p class="stat-value">4.2s</p>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Initialize charts for demo
 */
function initCharts() {
    // Add custom styling for charts
    Chart.defaults.font.family = "'Poppins', sans-serif";
    Chart.defaults.color = '#555';
    Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    Chart.defaults.plugins.tooltip.padding = 10;
    Chart.defaults.plugins.tooltip.cornerRadius = 5;
    Chart.defaults.plugins.tooltip.titleFont = {
        weight: 'bold',
        size: 14
    };
}

// Add custom styling for demo stats
document.addEventListener('DOMContentLoaded', function() {
    const style = document.createElement('style');
    style.textContent = `
        .stat-card {
            background-color: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
            margin-bottom: 20px;
        }
        
        .stat-card h5 {
            font-size: 0.9rem;
            margin-bottom: 10px;
            color: #666;
        }
        
        .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0;
        }
        
        .text-success {
            color: #28a745 !important;
        }
        
        .trades-table-container {
            max-height: 300px;
            overflow-y: auto;
        }
    `;
    document.head.appendChild(style);
});
